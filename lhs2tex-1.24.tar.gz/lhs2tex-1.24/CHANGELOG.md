# lhs2tex-1.24 (2020-05-01)

- Fix line number calculation for LINE pragmas (#81).
- Fix filepaths in preprocessor mode (#80).

# lhs2tex-1.23 (2020-02-25)

- Compatibility with ghc-8.8 and Cabal-3.0 (#76).
- Lexing of hexadecimal and octal literals (#74).

# lhs2tex-1.22 (2018-09-23)

- Compatibility with ghc-8.6.

# lhs2tex-1.21 (2018-09-10)

- Some code refactoring.
- Experimental markdown mode.
- Improved output when using deprecated modes (#59).
- Compatibility with ghc-8.4 (#69).
- Fix in the formatting directives parser (#64).

